$(function(e) {
	  $('#summernote').summernote({
		placeholder: '',
		tabsize: 3,
		height: 300
	  });
	});